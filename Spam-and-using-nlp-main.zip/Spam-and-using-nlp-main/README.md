# Spam-and-using-nlp
This project uses Natural Language Processing (NLP) techniques to classify text messages as either "spam" or "ham" (non-spam). The goal is to develop this project   that can accurately distinguish between spam and legitimate messages.
